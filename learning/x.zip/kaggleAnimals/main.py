import sys
sys.path.append('C:/git/kaggleAnimals/')
import utils



dfall, id_test, target = utils.load_processeddata()

X_train, y_train, X_valid, y_valid, X_test, le = split_train_valid_test(dfall, target)

