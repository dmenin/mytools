import sys
sys.path.append('C:/git/kaggleAnimals/')
import utils
import code_sklearn
import code_xgboost
import ensemble
from sklearn.metrics import log_loss
import numpy as np
import feat_selection
import pandas as pd
from xgboost.sklearn import XGBClassifier



dfall, id_test, target = utils.load_processeddata()
#dfall.Named = dfall.Named  + dfall.NameCommon
dfall = dfall.drop(['NameCommon'],axis=1)
#dfall[['Time','year', 'month', 'day', 'ageindays']]



#len(dfall.columns)
#zip(*np.unique(target, return_counts=True))
#
#dfall['ageindays'] =  (dfall['ageindays'] - np.average(dfall['ageindays'])) / np.std(dfall['ageindays'])
#dfall['ageindays'] = dfall['ageindays'].apply (lambda x: round(x,2))

#dfall = dfall[['Time','day']]
X_train, y_train, X_valid, y_valid, X_test, le = utils.split_train_valid_test(dfall, target)



model= XGBClassifier(base_score=0.5, colsample_bylevel=1, colsample_bytree=0.4,
       gamma=2, learning_rate=0.09, max_delta_step=0, max_depth=8,
       min_child_weight=1, missing=None, n_estimators=1000, nthread=-1,
       objective='multi:softprob', reg_alpha=0, reg_lambda=1,
       scale_pos_weight=1, seed=0, silent=True, subsample=0.5)
#model= XGBClassifier(base_score=0.5, colsample_bylevel=1, colsample_bytree=0.6,
#       gamma=2, learning_rate=0.09, max_delta_step=0, max_depth=10,
#       min_child_weight=1, missing=None, n_estimators=1000, nthread=-1,
#       objective='multi:softprob', reg_alpha=0, reg_lambda=1,
#       scale_pos_weight=1, seed=0, silent=True, subsample=0.6)
       
#model= XGBClassifier(n_estimators=1000, nthread=-1,objective='multi:softprob')



#feat selection - run only after data model has changed
feat_selection.xgb_feat_selection(model, dfall.columns, X_train, y_train, X_valid, y_valid, 40, verbose=True)


#X_train, X_valid, X_test =  feat_selection.apply_feat_sel_by_percent(X_train, X_valid, X_test, f_type='xgboost', percent=0.7)
data = [X_train, y_train, X_valid, y_valid, X_test]


#####Run to have an idea of the log loss on a simple model
model.fit(X_train, y_train)
preds = model.predict_proba(X_valid)
log_loss(y_valid, preds)
#0.7381            -> 0.72731
#0.7372 sem breed  -> 0.72546
#0.7362 is single breed  -> 0.72261
#0.7326 -  5 top breeds
#0.7291 -  sem cor + issingle color   -> 0.71466
#0.7263 pivot weekday ->                 0.71341


model.fit(X_train, y_train, eval_set=[(X_valid, y_valid)],
        eval_metric = 'mlogloss',early_stopping_rounds=50, verbose=True)
best_iter = model.best_iteration

y_valid_pred = model.predict_proba(X_valid, ntree_limit = best_iter)
log_loss(y_valid, y_valid_pred)



  
tag= "NameCommon"
y_valid_pred, y_test_pred = code_xgboost.clf_xgboost(data, tag=tag, cl_weight=None, random_state=0, verbose=True, xgb = model, scale=False)
print log_loss(y_valid, y_valid_pred)
#y_valid_pred, y_test_pred = code_sklearn.clf_log_regression(data, tag, 0, calibrated=False)
y_valid_pred, y_test_pred = code_sklearn.clf_random_forest(data, tag, 0, calibrated=True, scale=False)
print log_loss(y_valid, y_valid_pred)
y_valid_pred, y_test_pred =code_sklearn.clf_extra_trees(data, tag, 0, calibrated=True, scale=False)
print log_loss(y_valid, y_valid_pred)


  

    
             
    
################################################################    
#model.fit(X_train, y_train, eval_set=[(X_valid, y_valid)],
#        eval_metric = 'mlogloss',early_stopping_rounds=25, verbose=True)
#best_iter = model.best_iteration
#
#y_valid_pred = model.predict_proba(X_valid, ntree_limit = best_iter)
#log_loss(y_valid, y_valid_pred)
#0.80996454673095264
#0.80811


#X = np.vstack((X_train, X_valid))
#y = np.hstack((y_train, y_valid))
#model.fit(X, y)
#preds = model.predict_proba(X)
#log_loss(y, preds)
##0.7583225844949284
#################################################################################


    

    
    



#Yes this is correct. After that you just need to call  apply_mix_opt to obtained the final predictions. 
#This function applies EN_opt1, EN_opt2 and their calibrated versions and also makes the final (3rd-layer) ensemble.
#You could also call apply_en_opt_1 or apply_en_opt_2 to only use either EN_opt1 or EN_opt2 in the generation of the final predictions. 
#Once the predictions are computed the function make_prediction will generate the submission file.
#overfit, preds1 = ensemble.apply_en_opt_1(y_valid, tag, validation=False)
#log_loss(y_valid, overfit)
#preds2 = ensemble.apply_en_opt_2(y_valid, tag)
predsmix = ensemble.apply_mix_opt(y_valid, tag)






preds = predsmix
#utils.make_submission(foo, le, sub_name='sub.csv')



results = pd.read_csv("C:/git/kaggleAnimals/raw_data/sample_submission.csv")

results['Adoption'], results['Died'], results['Euthanasia'] = preds[:,0], preds[:,1], preds[:,2]
results['Return_to_owner'], results['Transfer'] =  preds[:,3], preds[:,4]

results.to_csv("C:/git/kaggleAnimals/NameCommon.csv", index=False)




################quando tiver modelos separados###############
#test_users_path='C:/git/kaggleAnimals/raw_data/test.csv'               
#test = pd.read_csv(test_users_path, sep=',')
#test= test.loc[(test.AnimalType == 'Cat')]    
#len(test)
#results = test
#preds = predsmix
#results['Adoption'], results['Died'], results['Euthanasia'] = preds[:,0], preds[:,1], preds[:,2]
#results['Return_to_owner'], results['Transfer'] =  preds[:,3], preds[:,4]
#results = results[['ID','Adoption', 'Died', 'Euthanasia','Return_to_owner','Transfer']]
#results.to_csv("C:/git/kaggleAnimals/ResultsAll.csv", index=False)
############################################################################
#    

################################################################################################
#from sklearn.grid_search import GridSearchCV
#xgb_params = [{                   
#               'gamma' : range(0,3)
#             , 'max_depth': range(7,12)     
#             , 'subsample' : [0.4, 0.5, 0.6]
#             , 'colsample_bytree' : [0.4, 0.5, 0.6]                          
#             , 'learning_rate' : [0.09, 0.1, 0.15]
#            }]
#
#clfXGB = GridSearchCV(XGBClassifier(objective='multi:softprob', n_estimators=1000, seed=0), xgb_params, scoring='f1')
#bestXGB = clfXGB.fit(X_train, y_train)
#print bestXGB.best_estimator_
#
##XGBClassifier(base_score=0.5, colsample_bylevel=1, colsample_bytree=0.6,
##       gamma=2, learning_rate=0.09, max_delta_step=0, max_depth=10,
##       min_child_weight=1, missing=None, n_estimators=1000, nthread=-1,
##       objective='multi:softprob', reg_alpha=0, reg_lambda=1,
##       scale_pos_weight=1, seed=0, silent=True, subsample=0.6)
#
#
#
#from sklearn.ensemble import RandomForestClassifier  
#forest_params = [{
#                #"criterion": ["gini", "entropy"],                
#                "max_depth": [15,20,25],
#                "max_features": [0.8,0.9,1],
#                "min_samples_split": [80,90,100],
#                "min_samples_leaf": range(1,5),
#                "bootstrap": [True, False]
#                }]    
#clfRF = GridSearchCV(RandomForestClassifier(n_estimators=500,n_jobs=-1,random_state=0), forest_params , scoring='f1')
#bestRF = clfRF.fit(X_train, y_train)
#print bestRF.best_estimator_
#                
##    RandomForestClassifier(bootstrap=True, class_weight=None, criterion='gini',
##            max_depth=15, max_features=0.9, max_leaf_nodes=None,
##            min_samples_leaf=2, min_samples_split=80,
##            min_weight_fraction_leaf=0.0, n_estimators=500, n_jobs=-1,
##            oob_score=False, random_state=0, verbose=0, warm_start=False)            
#
#
#from sklearn.ensemble import ExtraTreesClassifier  
#forest_params = [{
#                #"criterion": ["gini", "entropy"],                
#                "max_depth": [15,20,25],
#                "max_features": [0.8,0.9,1],
#                "min_samples_split": [80,90,100],
#                "min_samples_leaf": range(1,5),
#                "bootstrap": [True, False]
#                }]    
#clfET = GridSearchCV(ExtraTreesClassifier(n_estimators=500,n_jobs=-1,random_state=0), forest_params , scoring='f1')
#bestET = clfET.fit(X_train, y_train)
#print bestET.best_estimator_



from sklearn.linear_model import LogisticRegression
lr = LogisticRegression(n_jobs=-1, random_state=0, solver='newton-cg')

y_valid_pred, y_test_pred = code_sklearn.clf_sklearn(lr, 'foo', "LR", data, 0, True)
print log_loss(y_valid, y_valid_pred)    





from sklearn.neighbors import KNeighborsClassifier
neigh = KNeighborsClassifier(n_neighbors=15, leaf_size = 60, p=1, algorithm ='ball_tree')

y_valid_pred, y_test_pred = code_sklearn.clf_sklearn(neigh, 'foo', "neigh", data, 0, True)
print log_loss(y_valid, y_valid_pred)    






from sklearn.svm import SVC
clf = SVC(probability=True)
y_valid_pred, y_test_pred = 0,0
y_valid_pred, y_test_pred = code_sklearn.clf_sklearn(clf, 'foo', "svc", data, 0, False)
print log_loss(y_valid, y_valid_pred)   
 