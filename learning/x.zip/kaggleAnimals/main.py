import sys
sys.path.append('C:/git/kaggleAnimals/')
import utils
import code_sklearn
import code_xgboost
import ensemble
from sklearn.metrics import log_loss
import numpy as np
import feat_selection
import pandas as pd
from xgboost.sklearn import XGBClassifier



dfall, id_test, target = utils.load_processeddata()
#dfall['ageindaysNew'] = dfall['ageindays'] /float(np.max(dfall['ageindays'] ))



X_train, y_train, X_valid, y_valid, X_test, le = utils.split_train_valid_test(dfall, target)

model= XGBClassifier(base_score=0.5, colsample_bylevel=1, colsample_bytree=0.4,
       gamma=2, learning_rate=0.09, max_delta_step=0, max_depth=4,
       min_child_weight=1, missing=None, n_estimators=1000, nthread=-1,
       objective='multi:softprob', reg_alpha=0, reg_lambda=1,
       scale_pos_weight=1, seed=0, silent=True, subsample=0.5)
#model= XGBClassifier(objective='multi:softprob')
#feat selection
       
feat_selection.xgb_feat_selection(model, dfall.columns, X_train, y_train, X_valid, y_valid, 30, verbose=True)
X_train, X_valid, X_test =  feat_selection.apply_feat_sel_by_percent(X_train, X_valid, X_test, f_type='xgboost', percent=0.7)

       
        
data = [X_train, y_train, X_valid, y_valid, X_test]
model.fit(X_train, y_train)
preds = model.predict_proba(X_valid)
log_loss(y_valid, preds)
#0.8095 se fizer pivot no weekday - 	0.78979 no site
#0.80787 addicionei  deswexed e 70%




################################################################################################

from sklearn.grid_search import GridSearchCV
xgb_params = [{                   
               'gamma' : range(0,3)
             , 'max_depth': range(3,6)     
             , 'subsample' : [0.4, 0.5, 0.6]
             , 'colsample_bytree' : [0.4, 0.5, 0.6]                          
             , 'learning_rate' : [0.09, 0.1, 0.15]
            }]

clf = GridSearchCV(XGBClassifier(objective='multi:softprob', n_estimators=400, seed=0), xgb_params) # , scoring='f1'
best = clf.fit(X_train, y_train)
best.best_estimator_
#XGBClassifier(base_score=0.5, colsample_bylevel=1, colsample_bytree=0.4,
#       gamma=2, learning_rate=0.09, max_delta_step=0, max_depth=4,
#       min_child_weight=1, missing=None, n_estimators=400, nthread=-1,
#       objective='multi:softprob', reg_alpha=0, reg_lambda=1,
#       scale_pos_weight=1, seed=0, silent=True, subsample=0.5)
    
################################################################    
model.fit(X_train, y_train, eval_set=[(X_valid, y_valid)],
        eval_metric = 'mlogloss',early_stopping_rounds=25, verbose=True)
best_iter = model.best_iteration

y_valid_pred = model.predict_proba(X_valid, ntree_limit = best_iter)
log_loss(y_valid, y_valid_pred)
#0.80996454673095264
#0.80811


X = np.vstack((X_train, X_valid))
y = np.hstack((y_train, y_valid))
model.fit(X, y)
preds = model.predict_proba(X)
log_loss(y, preds)
#0.7583225844949284
#################################################################################


    
    
    
    



tag= "ALL"
#model= XGBClassifier(base_score=0.5, colsample_bylevel=1, colsample_bytree=0.4,
#       gamma=2, learning_rate=0.09, max_delta_step=0, max_depth=4,
#       min_child_weight=1, missing=None, n_estimators=400, nthread=-1,
#       objective='multi:softprob', reg_alpha=0, reg_lambda=1,
#       scale_pos_weight=1, seed=0, silent=True, subsample=0.5)


y_valid_pred, y_test_pred = code_xgboost.clf_xgboost(data, tag=tag, cl_weight=None, random_state=0, verbose=True, xgb = model)
log_loss(y_valid, y_valid_pred)




#code_sklearn.clf_random_forest(data, tag, 0, calibrated=False)
#code_sklearn.clf_log_regression(data, tag, 0, calibrated=False)
#code_sklearn.clf_extra_trees(data, tag, 0, calibrated=False)



            
    
    



#Yes this is correct. After that you just need to call  apply_mix_opt to obtained the final predictions. 
#This function applies EN_opt1, EN_opt2 and their calibrated versions and also makes the final (3rd-layer) ensemble.
#You could also call apply_en_opt_1 or apply_en_opt_2 to only use either EN_opt1 or EN_opt2 in the generation of the final predictions. 
#Once the predictions are computed the function make_prediction will generate the submission file.
preds1 = ensemble.apply_en_opt_1(y_valid, tag)
preds2 = ensemble.apply_en_opt_2(y_valid, tag)
predsmix = ensemble.apply_mix_opt(y_valid, tag)

len(predsmix)


###############quando tiver modelos separados###############
test_users_path='C:/git/kaggleAnimals/raw_data/test.csv'               
test = pd.read_csv(test_users_path, sep=',')
test= test.loc[(test.AnimalType == 'Cat')]    
len(test)
results = test
preds = predsmix
results['Adoption'], results['Died'], results['Euthanasia'] = preds[:,0], preds[:,1], preds[:,2]
results['Return_to_owner'], results['Transfer'] =  preds[:,3], preds[:,4]
results = results[['ID','Adoption', 'Died', 'Euthanasia','Return_to_owner','Transfer']]
results.to_csv("C:/git/kaggleAnimals/ResultsAll.csv", index=False)
###########################################################################
    


preds = predsmix
#utils.make_submission(foo, le, sub_name='sub.csv')



results = pd.read_csv("C:/git/kaggleAnimals/raw_data/sample_submission.csv")

results['Adoption'], results['Died'], results['Euthanasia'] = preds[:,0], preds[:,1], preds[:,2]
results['Return_to_owner'], results['Transfer'] =  preds[:,3], preds[:,4]

results.to_csv("C:/git/kaggleAnimals/predsmix.csv", index=False)

