import pickle
import pandas as pd
import numpy as np
from datetime import datetime, date
from sklearn.preprocessing import LabelEncoder
from sklearn.cross_validation import StratifiedShuffleSplit

def process_raw_data(train_users_path='C:/git/kaggleAnimals/raw_data/train_users.csv',
                     test_users_path='C:/git/kaggleAnimals/raw_data/test_users.csv'):

    
    train_users_path='C:/git/kaggleAnimals/raw_data/train.csv'
    test_users_path='C:/git/kaggleAnimals/raw_data/test.csv'
    

                             
    train = pd.read_csv(train_users_path, sep=',')
    test = pd.read_csv(test_users_path, sep=',')
    
    
    #train= train.loc[(train.AnimalType == 'Cat')]
    #test= test.loc[(test.AnimalType == 'Cat')]    
    
    
    train.rename(columns={'AnimalID': 'ID'}, inplace=True)
    train = train[['ID', 'Name', 'DateTime', 'AnimalType', 'SexuponOutcome', 'AgeuponOutcome', 'Breed', 'Color', 'OutcomeType', 'OutcomeSubtype']]
    test['OutcomeType']='test'
    test['OutcomeSubtype']='test'
    
    #set the subtype equals to the type when subtype is Na
    #train[:9][['OutcomeType', 'OutcomeSubtype']]
    train.OutcomeSubtype.fillna(train.OutcomeType, inplace=True)

    target = train['OutcomeType']
    #subtarget = train['OutcomeSubtype']
    test_ids = test['ID']
           
    print train.columns
    print test.columns
        
    ######################       APPLY LOGIC ON TRAIN AND TESTS 
    dfall = pd.concat((train, test), axis=0, ignore_index=True)


    #dropando for now
    dfall = dfall.drop(['OutcomeSubtype'],axis=1)
    dfall = dfall.drop(['OutcomeType'],axis=1)    
    
    dfall['Named'] = dfall.Name.apply(lambda x : not pd.isnull(x)).astype(int)



    
    #dfall.Name.value_counts()
    n = dict(zip(*np.unique(dfall.Name, return_counts=True)))
    for key, value in n.items():
        n[key] = value / 195.
    dfall['NameCommon'] = dfall.Name.apply(lambda x: n[x] if not pd.isnull(x) else 0)   
    dfall['NameCommon'] = dfall['NameCommon'].apply (lambda x: round(x,2))
    #dfall[['Name','NameCommon']]
    
    
    
    
    
    
    
    
    dfall = dfall.drop(['Name'],axis=1)
    dfall.index = dfall.ID
    dfall = dfall.drop(['ID'],axis=1)
    dfall = dfall.fillna(-1)  #Dont expect to have Nas at this point but just to be sure


    dfall['Breed']  = dfall.Breed.str.lower()    
#    dfall['isShorthair'].value_counts()  
#    dfall[:3]['Breed']  
    
    dfall['isMixed'] = dfall.Breed.str.contains('mix').astype(int)    
    dfall['isDomestic']  = dfall.Breed.str.contains('domestic').astype(int)    
    dfall['isShorthair']  = dfall.Breed.str.contains('shorthair').astype(int)
    
    dfall['Breed'] = dfall.Breed.str.replace('mix','')
    dfall['Breed'] = dfall.Breed.str.replace('shorthair','')
    dfall['Breed'] = dfall.Breed.str.replace('domestic','')
    dfall['Breed'] = dfall['Breed'].str.strip()

    dfall['Breed1'] = dfall.Breed.apply(lambda x : x.split('/')[0]).str.strip()
    dfall['Breed2'] = dfall.Breed.apply(lambda x :  'OneBreedOnly' if len(x.split('/')) == 1  else x.split('/')[1] ).str.strip()

    dfall['isSingleBreed']  = dfall.Breed2.str.contains('OneBreedOnly').astype(int)  
    #dfall[['Breed','Breed1','Breed2', 'isBreedchihuahua']]
    
    
    b1 = dict(zip(*np.unique(dfall.Breed1, return_counts=True)))
    b2 = dict(zip(*np.unique(dfall.Breed2, return_counts=True)))    
    from collections import Counter
    B1 = Counter(b1)
    B2 = Counter(b2)
    B = B1 + B2
    del B['']
    del B['OneBreedOnly']
    
    for b in B.most_common(5):        
        colName = 'isBreed'+b[0]
        dfall[colName] =  (dfall.Breed.str.contains(b[0])).astype(int)        
    #B1['pit bull']
    #B2['pit bull']
    #B['pit bull']    
    dfall = dfall.drop(['Breed'],axis=1)         
    dfall = dfall.drop(['Breed1'],axis=1)         
    dfall = dfall.drop(['Breed2'],axis=1)         
    




    #dfall.Color
    dfall['Color']  = dfall.Color.str.lower()
    #dfall['isTabby'] = dfall.Color.str.contains('tabby').astype(int)
    dfall['Color'] = dfall.Color.str.replace('tabby','')
    dfall['Color'] = dfall['Color'].str.strip()
    
    
    dfall['Color1'] = dfall.Color.apply(lambda x : x.split('/')[0]).str.strip()
    dfall['Color2'] = dfall.Color.apply(lambda x :  'SingleColor' if len(x.split('/')) == 1  else x.split('/')[1] ).str.strip()
    dfall['isSingleColor']  = dfall.Color2.str.contains('SingleColor').astype(int)
    
    c1 = dict(zip(*np.unique(dfall.Color1, return_counts=True)))
    c2 = dict(zip(*np.unique(dfall.Color2, return_counts=True)))    
    C1 = Counter(c1)
    C2 = Counter(c2)
    C = C1 + C2
#    c1['Tan']
#    c2['Tan']
#    C['Tan']        
    del C['SingleColor']
    
#    
#    for c in C.most_common(7):
#        colName = 'isColor'+c[0]
#        dfall[colName] =  (dfall.Color.str.contains(c[0])).astype(int)            
    
    dfall = dfall.drop(['Color'],axis=1)         
    dfall = dfall.drop(['Color1'],axis=1)         
    dfall = dfall.drop(['Color2'],axis=1)   
     
#    colors = ["Black","White","Brown","Blue","Orange","Calico","Chocolate","Gold","Red","Tan","Tortie","Yellow"]
#    for c in colors:
#        colName = 'isColor'+c        
#        dfall[colName] = dfall['Color'].str.contains(c).astype(int)
#    dfall = dfall.drop(['Color'],axis=1)
#    


    #dfall.DateTime.value_counts() 
    ##DateTime  
    dfall['DateTime'] = pd.to_datetime(dfall['DateTime'])
    dfall['Time'] = dfall['DateTime'].apply(lambda x: x.hour)  + dfall['DateTime'].apply(lambda x: x.minute)/60 
    
    dfall['DateTime'] = dfall['DateTime'].apply(pd.datetools.normalize_date)
    dac = np.vstack(dfall.DateTime.astype(str).apply(lambda x: map(int, x.split('-'))).values)
    dfall['year'] = dac[:,0]     
    dfall['month'] = dac[:,1]    
    dfall['day'] = dac[:,2]        
    dac_dates = [datetime(x[0],x[1],x[2]) for x in dac]    
    dfall['Weekday'] = np.array([d.isocalendar()[2] for d in dac_dates]) #WeekDay 1 to 7 (1 is monday)
    dfall = dfall.drop(['DateTime'],axis=1)
    #dfall['dac_weeknumber'] = np.array([d.isocalendar()[1] for d in dac_dates]) #WeekNumber 1 to 54
    
   # dfall_wd = pd.get_dummies(dfall.dac_w, prefix='dac_w')
   # dfall = dfall.drop(['DateTime', 'dac_w'], axis=1)
   # dfall = pd.concat((dfall, dfall_wd), axis=1)
    
    ###Age       
    def age_to_days(item):
        if item == -1:
            return -1
        if 'day' in item:
            return  int(item.split(' ')[0])
        if 'week' in item:
            return int(item.split(' ')[0])*7
        if 'month' in item:
            return int(item.split(' ')[0])*30
        if 'year' in item:
            return int(item.split(' ')[0])*365    
    
    dfall['ageindays'] =  dfall['AgeuponOutcome'].apply (lambda x: age_to_days(x))    
    dfall['ageindays'] = (dfall['ageindays']).astype(int)
    dfall = dfall.drop(['AgeuponOutcome'],axis=1)
    
     #dfall[['ageindays','AgeuponOutcome']] 
#    #Idade, count
#    (dfall['ageindays']).describe()
#    dfall.ageindays.value_counts().sort_values(ascending=False) 
#    zip(*np.unique(dfall.ageindays, return_counts=True))
        
    #Age intervals
#    av = dfall.ageindays.values
#    #AgeRange    
#    interv = range (0,8030,30)
#    
#    def get_interv_value(age):
#        iv = len(interv) +1
#        for i in range(len(interv)):
#            if age < interv[i]:
#                iv = i 
#                break
#        return iv
#    dfall['age_interv'] = dfall.ageindays.apply(lambda x: get_interv_value(x))    
#    dfall_intervals = pd.get_dummies(dfall.age_interv, prefix='age_interv')
#    dfall = dfall.drop(['age_interv'], axis=1)
#    dfall = pd.concat((dfall, dfall_intervals), axis=1)        
#    dfall = dfall.drop(['ageindays'], axis=1)    
#        

#    #Seasons    
#    Y = 2000
#    seasons = [(0, (date(Y,  1,  1),  date(Y,  3, 20))),  #'winter'
#               (1, (date(Y,  3, 21),  date(Y,  6, 20))),  #'spring'
#               (2, (date(Y,  6, 21),  date(Y,  9, 22))),  #'summer'
#               (3, (date(Y,  9, 23),  date(Y, 12, 20))),  #'autumn'
#               (0, (date(Y, 12, 21),  date(Y, 12, 31)))]  #'winter'
#    def get_season(dt):
#        dt = dt.date()
#        dt = dt.replace(year=Y)
#        return next(season for season, (start, end) in seasons
#                    if start <= dt <= end)
#    dfall['season_dac'] = np.array([get_season(dt) for dt in dac_dates])
#    
     
    

#    
    dfall['DeSexed'] = 0
    dfall.loc[(dfall.SexuponOutcome =='Unknown'), 'DeSexed'] = -1
    dfall.loc[(dfall.SexuponOutcome =='Neutered Male'), 'DeSexed'] = 1
    dfall.loc[(dfall.SexuponOutcome =='Spayed Female'), 'DeSexed'] = 1
    
    dfall.loc[(dfall.SexuponOutcome =='Spayed Female'), 'Sex'] = 'Female'
    dfall.loc[(dfall.SexuponOutcome =='Intact Female'), 'Sex'] = 'Female'
    dfall.loc[(dfall.SexuponOutcome =='Unknown'), 'Sex'] = 'Unknown'
    dfall.loc[(dfall.SexuponOutcome =='Neutered Male'), 'Sex'] = 'Male'
    dfall.loc[(dfall.SexuponOutcome =='Intact Male'), 'Sex'] = 'Male'
    dfall = dfall.drop(['SexuponOutcome'],axis=1)
#    
#        elif len(np.unique(dfall[col])) >2:
#            print 'Normalizing: ',col, '-',len(np.unique(dfall[col])), 'different values'
#            dfall[col] = dfall[[col]].apply(lambda x: (x - x.mean()) / (x.std())) #do not remove the double [] from theright side of the equasion - doesnt work
#        else:
#            print 'Not touching: ',col
#    
    #nao parece ter ajudado muito
    #dfall['ageindays'] = dfall[['ageindays']].apply(lambda x: (x - x.mean()) / (x.std())) 
            
         
    extra_one_hot = ['Weekday','season_dac']# ['Hour', 'Weekday','DeSexed'] #Hour, Weekday?
    donot_one_hot = ['OutcomeType', 'OutcomeSubtype']
    for col in dfall.columns:    
        if ((col not in donot_one_hot) and (dfall[col].dtypes == object or col in extra_one_hot)):        
            print 'Dummying: ',col
            dfall_dummy = pd.get_dummies(dfall[col], prefix='is'+col)
            dfall = dfall.drop([col], axis=1)
            dfall = pd.concat((dfall, dfall_dummy), axis=1)
        else:
            print 'Not touching: ',col
            
    
    dfall.to_pickle('C:/git/kaggleAnimals/data/df_all.pkl')
    pickle.dump(test_ids, open('C:/git/kaggleAnimals/data/id_test.pkl', 'wb'))
    pickle.dump(target, open('C:/git/kaggleAnimals/data/target.pkl', 'wb'))        





def load_processeddata(dfall_path='C:/git/kaggleAnimals/data/df_all.pkl',
                 id_test_path='C:/git/kaggleAnimals/data/id_test.pkl',
                 target_path='C:/git/kaggleAnimals/data/target.pkl'):

    """
    Load the data computed and saved by process_raw_data function.
    """
    print "Loading data"
    dfall = pickle.load(open(dfall_path, 'rb'))
    id_test = pickle.load(open(id_test_path, 'rb'))
    target = pickle.load(open(target_path, 'rb'))
    print dfall.shape
    return dfall, id_test, target
    
    

def split_train_valid_test(dfall, target, 
                           #save_path='C:/git/Airbnb/other_solutions/sandro/train_valid_test.pkl',
                           random_state=123456):
    
    #Spliting training and test data
    piv_train = len(target) 
    vals = dfall.values
    X = vals[:piv_train]
    X_test = vals[piv_train:]
    
    le = LabelEncoder()
    y = le.fit_transform(target.values)
    
    #The original training set is split into X_train (80%) + X_valid (20%)
    sss = StratifiedShuffleSplit(y, 1, test_size=0.2, random_state=random_state)
    for id_train, id_valid in sss:
        X_train, X_valid = X[id_train], X[id_valid]
        y_train, y_valid = y[id_train], y[id_valid]      
    
    return X_train, y_train, X_valid, y_valid, X_test, le
        