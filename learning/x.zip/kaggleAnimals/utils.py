import pickle
import pandas as pd
import numpy as np
from datetime import datetime, date
from sklearn.preprocessing import LabelEncoder
from sklearn.cross_validation import StratifiedShuffleSplit

def process_raw_data(train_users_path='C:/git/kaggleAnimals/raw_data/train_users.csv',
                     test_users_path='C:/git/kaggleAnimals/raw_data/test_users.csv',
                     submission_path='C:/git/kaggleAnimals/raw_data/sessions.csv'):
    train_users_path='C:/git/kaggleAnimals/raw_data/train.csv'
    test_users_path='C:/git/kaggleAnimals/raw_data/test.csv'
    submission_path='C:/git/kaggleAnimals/raw_data/sessions.csv'                         
                             
    train = pd.read_csv(train_users_path, sep=',')
    test = pd.read_csv(test_users_path, sep=',')
    
    
    
    train.rename(columns={'AnimalID': 'ID'}, inplace=True)
    train = train[['ID', 'Name', 'DateTime', 'AnimalType', 'SexuponOutcome', 'AgeuponOutcome', 
                   'Breed', 'Color', 'OutcomeType', 'OutcomeSubtype']]
    test['OutcomeType']='test'
    test['OutcomeSubtype']='test'
    
    #set the subtype equals to the type when subtype is Na
    #train[:9][['OutcomeType', 'OutcomeSubtype']]
    train.OutcomeSubtype.fillna(train.OutcomeType, inplace=True)
    
    
    target = train['OutcomeType']
    subtarget = train['OutcomeSubtype']
    test_ids = test['ID']
    
    
    
    print train.columns
    print test.columns
    
    
    ######################       APPLY LOGIC ON TRAIN AND TESTS 
    len_train_before = len(train)
    len_test_before = len(test)
    
    #dropando for now
    dfall = dfall.drop(['OutcomeSubtype'],axis=1)
    
    trainlen = train.shape[0]
    dfall = pd.concat((train, test), axis=0, ignore_index=True)
    dfall = dfall.drop(['Name'],axis=1)
    dfall.index = dfall.ID
    dfall = dfall.drop(['ID'],axis=1)
    dfall = dfall.fillna(-1)  #Dont expect to have Nas at this point but just to be sure
    
    ##DateTime
    dfall['DateTime'] = pd.to_datetime(dfall['DateTime'])
    dfall['DateTime'] = dfall['DateTime'].apply(pd.datetools.normalize_date)
    dac = np.vstack(dfall.DateTime.astype(str).apply(lambda x: map(int, x.split('-'))).values)
    dfall['dac_y'] = dac[:,0]
    dfall['dac_m'] = dac[:,1]
    dfall['dac_d'] = dac[:,2]
    
    
    dac_dates = [datetime(x[0],x[1],x[2]) for x in dac]
    dfall['dac_wn'] = np.array([d.isocalendar()[1] for d in dac_dates])
    dfall['dac_w'] = np.array([d.weekday() for d in dac_dates])
    dfall_wd = pd.get_dummies(dfall.dac_w, prefix='dac_w')
    dfall = dfall.drop(['DateTime', 'dac_w'], axis=1)
    dfall = pd.concat((dfall, dfall_wd), axis=1)
    
    
    Y = 2000
    seasons = [(0, (date(Y,  1,  1),  date(Y,  3, 20))),  #'winter'
               (1, (date(Y,  3, 21),  date(Y,  6, 20))),  #'spring'
               (2, (date(Y,  6, 21),  date(Y,  9, 22))),  #'summer'
               (3, (date(Y,  9, 23),  date(Y, 12, 20))),  #'autumn'
               (0, (date(Y, 12, 21),  date(Y, 12, 31)))]  #'winter'
    def get_season(dt):
        dt = dt.date()
        dt = dt.replace(year=Y)
        return next(season for season, (start, end) in seasons
                    if start <= dt <= end)
    dfall['season_dac'] = np.array([get_season(dt) for dt in dac_dates])
    
    
    ###Age
    #Function copied from:
    #https://www.kaggle.com/andraszsom/shelter-animal-outcomes/age-gender-and-breed-vs-outcome
    def age_to_days(item):
        # convert item to list if it is one string
        if type(item) is str:
            item = [item]
        ages_in_days = np.zeros(len(item))
        for i in range(len(item)):
            # check if item[i] is str
            if type(item[i]) is str:
                if 'day' in item[i]:
                    ages_in_days[i] = int(item[i].split(' ')[0])
                if 'week' in item[i]:
                    ages_in_days[i] = int(item[i].split(' ')[0])*7
                if 'month' in item[i]:
                    ages_in_days[i] = int(item[i].split(' ')[0])*30
                if 'year' in item[i]:
                    ages_in_days[i] = int(item[i].split(' ')[0])*365    
            else:
                # item[i] is not a string but a nan
                ages_in_days[i] = 0
        return ages_in_days
        
    
    dfall['ageindays'] = age_to_days(dfall['AgeuponOutcome'])
    dfall = dfall.drop(['AgeuponOutcome'],axis=1)
    
    av = dfall.ageindays.values
    #AgeRange
    #(One-hot encoding of the edge according these intervals)
    interv =  [0, 100,200,300,400,500,600,700,800,900,1000, 2000, 3000, 4000, 5000, 6000, 7000, 8030]
    def get_interv_value(age):
        iv = len(interv) +1
        for i in range(len(interv)):
            if age < interv[i]:
                iv = i 
                break
        return iv
    
    
    dfall['age_interv'] = dfall.ageindays.apply(lambda x: get_interv_value(x))
    #dfall.age_interv.value_counts()
    dfall_intervals = pd.get_dummies(dfall.age_interv, prefix='age_interv')
    dfall = dfall.drop(['age_interv'], axis=1)
    dfall = pd.concat((dfall, dfall_intervals), axis=1)
    
    
    dfall['DeSexed'] = 0
    dfall.loc[(dfall.SexuponOutcome =='Unknown'), 'DeSexed'] = -1
    dfall.loc[(dfall.SexuponOutcome =='Neutered Male'), 'DeSexed'] = 1
    dfall.loc[(dfall.SexuponOutcome =='Spayed Female'), 'DeSexed'] = 1
    
    dfall.loc[(dfall.SexuponOutcome =='Spayed Female'), 'Sex'] = 'Female'
    dfall.loc[(dfall.SexuponOutcome =='Intact Female'), 'Sex'] = 'Female'
    dfall.loc[(dfall.SexuponOutcome =='Unknown'), 'Sex'] = 'Unknown'
    dfall.loc[(dfall.SexuponOutcome =='Neutered Male'), 'Sex'] = 'Male'
    dfall.loc[(dfall.SexuponOutcome =='Intact Male'), 'Sex'] = 'Male'
    dfall = dfall.drop(['SexuponOutcome'],axis=1)
    
    #dfall.Breed.value_counts()
    #dfall.NewBreed.value_counts()
    breeds_threshold = 3
    breeds = dict(zip(*np.unique(dfall.Breed, return_counts=True)))
    dfall.Breed = dfall.Breed.apply(lambda x: 'OTHER' if breeds[x] < breeds_threshold else x)
    
    #dfall.Color.value_counts()
    #dfall.NewColor.value_counts()
    colors_threshold = 3
    colors = dict(zip(*np.unique(dfall.Color, return_counts=True)))
    dfall.Color = dfall.Color.apply(lambda x: 'OTHER' if colors[x] < colors_threshold else x)
    
    
    extra_one_hot = ['DeSexed']
    for col in dfall.columns:    
        if ((col != 'OutcomeType') and (col != 'OutcomeSubtype') and (dfall[col].dtypes == object or col in extra_one_hot)):
        #if ((col == 'Sex')):    
            print 'Dummying: ',col
            dfall_dummy = pd.get_dummies(dfall[col], prefix='is'+col)
            dfall = dfall.drop([col], axis=1)
            dfall = pd.concat((dfall, dfall_dummy), axis=1)
        else:
            print 'Not touching: ',col
            
            
    dfall.to_pickle('C:/git/kaggleAnimals/data/df_all.pkl')
    pickle.dump(test_ids, open('C:/git/kaggleAnimals/data/id_test.pkl', 'wb'))
    pickle.dump(target, open('C:/git/kaggleAnimals/data/target.pkl', 'wb'))        





def load_processeddata(dfall_path='C:/git/kaggleAnimals/data/df_all.pkl',
                 id_test_path='C:/git/kaggleAnimals/data/id_test.pkl',
                 target_path='C:/git/kaggleAnimals/data/target.pkl'):
    """
    Load the data computed and saved by process_raw_data function.
    """
    dfall = pickle.load(open(dfall_path, 'rb'))
    id_test = pickle.load(open(id_test_path, 'rb'))
    target = pickle.load(open(target_path, 'rb'))
    print dfall.shape
    return dfall, id_test, target
    
    

def split_train_valid_test(dfall, target, 
                           #save_path='C:/git/Airbnb/other_solutions/sandro/train_valid_test.pkl',
                           random_state=123456):
    
    #Spliting training and test data
    piv_train = len(target) 
    vals = dfall.values
    X = vals[:piv_train]
    X_test = vals[piv_train:]
    
    le = LabelEncoder()
    y = le.fit_transform(target.values)
    
    #The original training set is split into X_train (80%) + X_valid (20%)
    sss = StratifiedShuffleSplit(y, 1, test_size=0.2, random_state=random_state)
    for id_train, id_valid in sss:
        X_train, X_valid = X[id_train], X[id_valid]
        y_train, y_valid = y[id_train], y[id_valid]      
    
    return X_train, y_train, X_valid, y_valid, X_test, le
        